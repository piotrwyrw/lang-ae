package net.piotrwyrw;

public class LexerError extends Exception {

    public LexerError(String message) {
        super(message);
    }

}
