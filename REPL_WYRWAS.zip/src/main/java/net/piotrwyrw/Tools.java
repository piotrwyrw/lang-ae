package net.piotrwyrw;

public class Tools {

    public static String leftpad(int d) {
        return "\t".repeat(d);
    }

}
