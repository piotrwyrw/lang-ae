package net.piotrwyrw;

public class SolverError extends Exception {

    public SolverError(String message) {
        super(message);
    }

}
