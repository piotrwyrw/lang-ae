package net.piotrwyrw.ast;

public abstract class Node implements RecursiveNodePrint {}