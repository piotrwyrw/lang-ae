package net.piotrwyrw.ast;

public interface RecursiveNodePrint {

    public String dump(int lpad);

}
