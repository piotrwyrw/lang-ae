package net.piotrwyrw.ast;

public abstract class SolvableNode extends Node {}