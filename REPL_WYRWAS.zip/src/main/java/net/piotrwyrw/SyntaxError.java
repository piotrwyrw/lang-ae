package net.piotrwyrw;

public class SyntaxError extends Exception {

    public SyntaxError(String message) {
        super(message);
    }
}