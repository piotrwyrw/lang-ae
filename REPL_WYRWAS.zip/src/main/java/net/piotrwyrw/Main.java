package net.piotrwyrw;

/**
 * @author Piotr K. Wyrwas
 */

public class Main {

    public static void main(String[] args) {
        new ReadEvalPrintLoop();
    }

}
